a=1
b=2
c=a+b
d=c-1+a
d=d*a
print(d)
print(a,b,c)
