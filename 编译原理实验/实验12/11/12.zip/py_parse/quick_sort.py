class Student{
def __init__(a){
    print(1)
}
}

