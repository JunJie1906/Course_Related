a = 'abc'
b = '1b23'
c = '2'
print(a+b+c)
print('123abcd321'+b)

