package easy_factory_cal;

public class Mul extends Calculation {

	public Mul(int x1, int x2) {
		super(x1, x2);
	}

	public void cal() {
		System.out.print(this.x1 * this.x2);
	}
}