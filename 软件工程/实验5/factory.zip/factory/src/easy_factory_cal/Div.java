package easy_factory_cal;

public class Div extends Calculation {

	public Div(int x1, int x2) {
		super(x1, x2);
	}

	public void cal() {
		System.out.print(this.x1 / this.x2);
	}
}
