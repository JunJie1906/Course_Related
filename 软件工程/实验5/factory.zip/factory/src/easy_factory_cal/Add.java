package easy_factory_cal;

public class Add extends Calculation {
	public Add(int x1, int x2) {
		super(x1, x2);
	}

	public void cal() {
		System.out.println(this.x1 + this.x2);
	}
}
