package easy_factory_cal;

public class Calculation {
	protected int x1, x2;

	public Calculation(int x1, int x2) {
		this.x1 = x1;
		this.x2 = x2;
	}
}
