package easy_factory_cal;

public class CalEasyFactory {
	private int x1, x2;
	private String opt;

	public CalEasyFactory(int x1, int x2, String opt) {
		this.x1 = x1;
		this.x2 = x2;
		this.opt = opt;
	}

	public void cal() {
		if (opt.contentEquals("+")) {
			Add add = new Add(this.x1, this.x2);
			add.cal();
		} else {
			if (opt.contentEquals("-")) {
				Sub sub = new Sub(this.x1, this.x2);
				sub.cal();
			} else {
				if (opt.contentEquals("*")) {
					Mul mul = new Mul(this.x1, this.x2);
					mul.cal();
				} else {
					if (opt.contentEquals("/")) {
						Div div = new Div(this.x1, this.x2);
						div.cal();
					}
				}
			}
		}
	}

}
