package cal_class;

public class Operation {
	private int x1, x2;
	private String opt;

	public Operation(int x1, int x2, String opt) {
		this.x1 = x1;
		this.x2 = x2;
		this.opt = opt;
	}

	public void cal() {
		if (opt.contentEquals("+")) {
			System.out.println(x1 + x2);
		} else {
			if (opt.contentEquals("-")) {
				System.out.println(x1 - x2);
			} else {
				if (opt.contentEquals("*")) {
					System.out.println(x1 * x2);
				} else {
					if (opt.contentEquals("/")) {
						System.out.println(x1 / x2);
					}
				}
			}
		}
	}

	public static void main(String argu[]) {
		Operation opt = new Operation(12, 23, "*");
		opt.cal();
	}
}
