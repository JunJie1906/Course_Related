package factory_cal;

public class DivFactory implements Factory {

	@Override
	public Calculation createOperation() {
		// TODO Auto-generated method stub
		return new Div();
	}

}
