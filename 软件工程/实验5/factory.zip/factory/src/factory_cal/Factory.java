package factory_cal;

public interface Factory {
	public Calculation createOperation();
}
