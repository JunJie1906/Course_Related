package factory_cal;

public class Mul implements Calculation {

	@Override
	public void Cal(double x1, double x2) {
		// TODO Auto-generated method stub
		System.out.println(x1 * x2);
	}

}
