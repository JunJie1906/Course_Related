package factory_cal;

public interface Calculation {
	public void Cal(double x1, double x2);
}
