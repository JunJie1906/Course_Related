package factory_cal;

public class SubFactory implements Factory {

	@Override
	public Calculation createOperation() {
		// TODO Auto-generated method stub
		return new Sub();
	}
}
