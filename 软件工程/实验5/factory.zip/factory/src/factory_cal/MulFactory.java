package factory_cal;

public class MulFactory implements Factory {

	@Override
	public Calculation createOperation() {
		// TODO Auto-generated method stub
		return new Mul();
	}

}
