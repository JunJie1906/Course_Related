package factory_cal;

public class AddFactory implements Factory {

	@Override
	public Calculation createOperation() {
		// TODO Auto-generated method stub
		return new Add();
	}
}
