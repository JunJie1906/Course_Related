package Calculation;

import java.io.IOException;
import java.util.Scanner;

public class Cal1 {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		int x1, x2;
		System.out.println("please input a number: ");
		x1 = sc.nextInt();
		System.out.println("please input another number: ");
		x2 = sc.nextInt();
		System.out.println("please input the operation: ");
		String opt = sc.next();
		sc.close();

		if (opt.contentEquals("+")) {
			System.out.println(x1 + x2);
		} else {
			if (opt.contentEquals("-")) {
				System.out.println(x1 - x2);
			} else {
				if (opt.contentEquals("*")) {
					System.out.println(x1 * x2);
				} else {
					if (opt.contentEquals("/")) {
						System.out.println(x1 / x2);
					}
				}
			}
		}
	}

}
